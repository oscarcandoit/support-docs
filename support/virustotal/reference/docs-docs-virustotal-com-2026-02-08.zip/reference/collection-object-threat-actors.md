---
title: "🔀🔒 threat_actors"
source: "https://docs.virustotal.com/reference/collection-object-threat-actors"
scraped_at: "2026-02-08T06:35:42.731Z"
---

The *threat_actors* relationship return the list of ***all threat actors in the Collection***.

This relationship can be retrieved using the [relationships API](/reference/get-collections-relationship) endpoint. The response contains a list of [Threat Actor](/reference/threat-actors-object) objects.

/collections/{id}/threat_actorsExample
```
`{
 "data": [
 <MDXishSnakeCase0>,
 <MDXishSnakeCase0>,
 ...
 ],
 "links": {
 "next": <string>,
 "self": <string>
 },
 "meta": {
 "count": <int>,
 "cursor": <string>
 }
}`
```

```
`{
 "meta": {
 "count": 2,
 "cursor": "eyJsaW1pdCI6IDEsICJvZmZzZXQiOiAxfQ=="
 },
 "data": [
 {
 "attributes": {
 "info": {
 "synonyms": [
 "Palmetto Fusion",
 "Allanite"
 ],
 "since": "2017",
 "refs": [
 "https://dragos.com/adversaries.html",
 "https://dragos.com/blog/20180510Allanite.html"
 ],
 "victimology": "Electric utilities, US and UK",
 "mode-of-operation": "Watering-hole and phishing leading to ICS recon and screenshot collection",
 "capabilities": "Powershell scripts, THC Hydra, SecretsDump, Inveigh, PSExec"
 },
 "link": "https://www.misp-project.org/galaxy.html#_allanite",
 "uuid": "a9000eaf-2b75-4ec7-8dcf-fe1bb5c77470",
 "name": "ALLANITE",
 "description": "Adversaries abusing ICS (based on Dragos Inc adversary list).\nALLANITE accesses business and industrial control (ICS) networks, conducts reconnaissance, and gathers intelligence in United States and United Kingdom electric utility sectors. Dragos assesses with moderate confidence that ALLANITE operators continue to maintain ICS network access to: (1) understand the operational environment necessary to develop disruptive capabilities, (2) have ready access from which to disrupt electric utilities.\nALLANITE uses email phishing campaigns and compromised websites called watering holes to steal credentials and gain access to target networks, including collecting and distributing screenshots of industrial control systems. ALLANITE operations limit themselves to information gathering and have not demonstrated any disruptive or damaging capabilities.\nALLANITE conducts malware-less operations primarily leveraging legitimate and available tools in the Windows operating system."
 },
 "type": "threat_actor",
 "id": "allanite",
 "links": {
 "self": "https://virustotal.com/api/v3/threat_actors/allanite"
 }
 }
 ],
 "links": {
 "self": "https://virustotal.com/api/v3/collections/testdata_collection/threat_actors?limit=1",
 "next": "https://virustotal.com/api/v3/collections/testdata_collection/threat_actors?cursor=eyJsaW1pdCI6IDEsICJvZmZzZXQiOiAxfQ%3D%3D&limit=1"
 }
}`
```