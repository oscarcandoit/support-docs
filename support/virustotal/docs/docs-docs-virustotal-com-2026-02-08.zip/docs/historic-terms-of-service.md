---
title: "Historic Terms of Service"
source: "https://docs.virustotal.com/docs/historic-terms-of-service"
scraped_at: "2026-02-08T06:19:18.844Z"
---

[**Current Terms of Service**](https://cloud.google.com/terms/secops)

**Last Updated January 27, 2021**

**Welcome**

These Terms of Service govern your access to and use of [www.virustotal.com](http://www.virustotal.com) (our “**Site**”) and our products and services (collectively, the "**Service**"), and any information, text, graphics, URLs, files, audio, video, photos or other materials uploaded, downloaded or appearing on the Service ("**Samples**"). Any reference to “you” or “your” means you as a user of the Service, any reference to “we”, “us”, “our” or “VirusTotal” is to Chronicle Security Ireland Limited (“**CSIL**”), an Irish Limited Company with registered number 507502, the company that owns VirusTotal. Both VirusTotal and CSIL are owned by Chronicle LLC.

Whether you are a member of the public, an antivirus, scanning, sandbox or other security partner (“**Partner**”), or a security-minded organization (collectively, the “**Community**”) using and contributing Samples to the Service, by using any part of the Service, you agree and consent to these Terms of Service including terms that limit our liability or affect your legal rights, any referenced and incorporated guidelines and policies, including our [**Sample & Community Content Guidelines**](#sample-and-community-content-guidelines) (which explain how to safely share Samples through the Service), the terms of our [**Privacy Policy**](/docs/privacy-policy) (which explains how we may collect, use and share personal information you provide to us), and any additional terms specific to your particular use of the Service which become part of your agreement with us (collectively, the “**Terms**”). If you are using the Service on behalf of a business, you represent to us that you have authority to bind that business or entity to these Terms, and that business accepts these Terms.  

**Restrictions on Your Use of the Service**

You agree that you may not use or attempt to:

- Use the Service in any way that breaches any applicable local, national, or international law or regulation.

- Use the Service in any way which could infringe the rights or interests of VirusTotal, the Community or any third party, including for example, to prove or disprove a concept or discredit, or bait any actor in the anti-malware space.

- Copy, reproduce, alter, modify, create derivative works, publicly display, republish, upload, post, transmit, resell or distribute in any way material, information or functionalities from the Service – including, without limitation, using the Service in any way for antivirus/URL scanner testing or that could directly or indirectly harm, compete with, or otherwise hinder the antivirus industry/URL scanner industry.

- Transfer any rights granted to you under the Terms.

- Use the Service for any illegal activity or output, or in any way that exposes VirusTotal, you, members of the Community or our Partners to harm.

- Engage in any activity that could damage, overload, harm or impede the normal functioning of the Service.

- Obtain or use any Samples except as specifically permitted by the Service or use or attempt to use the Service to mine information in any way that could identify individual persons in their private capacity, attempt to access or misappropriate content contained in any Sample, or otherwise use the Service or Samples for any purpose other than to detect and prevent malware in a non-commercial personal or organizational capacity.

- Publicly attribute the intelligence you receive through the Service to any VirusTotal Partner (antivirus vendors, URL scanning engines, file characterization tools, etc.) without the individual Partner’s express permission.

- Attempt to gain unauthorized access to our Site, the server on which our Site is stored or any server, computer or database connected to our Site.

- Attack, or attempt to attack our Site via a denial-of-service attack or a distributed denial-of service attack.

- Use or allow any third party under your control to submit Samples that are subject to the International Traffic in Arms Regulations (“**ITAR**”) maintained by the U.S. Department of State or do any other thing to cause CSIL to provide a defense service as defined by the ITAR, or otherwise use the Service except as expressly allowed under these Terms.

**Safe Participation in the Community**

You must be 18 years or older to use the Service. You represent and warrant that you are at least 18 years old and of legal age to form a binding contract. While VirusTotal has commercial relationships with select members of the Community (organizations, institutions and Partners) public access to the VirusTotal Site is only available free of charge.

VirusTotal offers certain functionality that may require the creation of a personal account (e.g. to participate in the VirusTotal Community). You promise to provide us with accurate, complete and updated registration information. Depending on the information provided in the registration and profile building process, your account may uniquely identify you. Any comment, post or other activity you engage in with the Community when using your account will generate content attributed to you (“**Content**”). 

To the extent you use any password/keys/credentials to access the Service, you are exclusively responsible for generating unique and complex credentials, safeguarding them, and for any activities or actions taken on the Service using such credentials. You may not transfer your account to anyone else.

#### **Sample And Community Content Guidelines**[](#sample-and-community-content-guidelines)

To the extent you elect to contribute any Sample to the Community, you confirm that all content contained in the Sample complies with these Terms and our [Privacy Policy](/docs/privacy-policy), that you are either the original owner of the Sample you submit or that you have the necessary rights and permissions to irrevocably contribute the Sample and share it, and information about it, with the Community.

You understand that if you submitting any Sample, the Sample is immediately shared for review by the Service’s Partners, and the resulting intelligence report is shared with you and, and with the Partners, which use the results to improve their own systems. As such, by contributing a Sample, you are contributing to the effort to raise global IT security levels.

While you retain any ownership rights in the original material contained in the Sample, when you upload or otherwise submit a copy of the Sample, you give VirusTotal (and those we work with) a worldwide, royalty free, irrevocable and transferable licence to use, edit, host, store, reproduce, modify, create derivative works, communicate, publish, publicly perform, publicly display and distribute all content contained in the Sample.

YOU FURTHER AGREE THAT YOU WILL ONLY UPLOAD SAMPLES THAT YOU WISH TO PUBLICLY SHARE AND THAT IN ANY CASE, YOU WILL NOT KNOWINGLY SUBMIT ANY SAMPLE TO THE SERVICE THAT CONTAINS CONFIDENTIAL OR COMMERCIALLY SENSITIVE DATA OR PERSONAL DATA OF ANY INDIVIDUAL WITHOUT LAWFUL PERMISSION.

Although we have no obligation to monitor use of the Service, user Content or any Samples, we may monitor the Service to detect and prevent fraudulent activity or violations of these Terms and retain absolute discretion to remove Samples, Content or users from the Service at any time and for any reason without notice. At the same time, to promote the security of the Community and information sharing accountability, accounts and Samples contributed by the Community (for example, comments, posts, etc.) generally will not be removed from the Service, unless they are illegal, violate the lawful rights of an individual, serve any other unethical/malicious purpose, or otherwise violate these Terms.

IF YOU DO NOT WANT TO PUBLICLY SHARE A SAMPLE IN THE MANNER SET OUT IN THESE TERMS OR IN THE [PRIVACY POLICY](/docs/privacy-policy), DO NOT SEND IT/CONTRIBUTE IT TO THE SERVICE AS THE SERVICE IS DESIGNED TO WORK THROUGH THE COLLECTIVE AGGREGATION AND SHARING OF THREAT-INTELLIGENCE WITH AND THROUGH THE COMMUNITY.

If you think someone is infringing your copyright, you can send us a notice of claimed infringement at [[email&#160;protected]](/cdn-cgi/l/email-protection#f6929b9597db9791939882b6919999919a93d895999b), and we’ll take appropriate action. VirusTotal&#x27;s policies provide for the termination, in appropriate circumstances, of repeat infringers’ access to the Service. 

**VirusTotal Rights**

All rights, title, and interest in and to the Service (excluding third party brand names) are and will remain the exclusive property of VirusTotal and its licensors. Nothing in these Terms should be construed as conferring by implication or otherwise any license or right under any copyright, patent, trademark, database right, sui generis right or other intellectual property or proprietary interest of VirusTotal, its licensors or any third party. We reserve the right to remove any Samples without prior notice and at our sole discretion. Nothing in our Terms gives you a right to use the VirusTotal trademarks, logos, domain names, and other distinctive brand features.

Any Samples, feedback, comments, or suggestions you may provide to, or regarding VirusTotal or the Service is entirely voluntary. We are free to use any feedback, comments or suggestions as we see fit and without obligation to you and reserve the right to remove any Sample without prior notice and at our sole discretion.

**Changes in Service**

The Service provided by VirusTotal is constantly evolving, and the form and nature of the Service that VirusTotal provides may change from time to time without prior notice to you. Any changes to the Service, including the release of new VirusTotal features, are subject to the Terms then in effect. In addition, VirusTotal may stop (permanently or temporarily) providing the Service (or any features within the Service) without providing prior notice. We also retain the right to create limits on your use of the Service including storage, at our sole discretion, at any time without prior notice to you.

**Disclaimers**

Your access to and use of the Service is at your own risk. You understand and agree that the Service is provided to you on an "AS IS" WITHOUT REPRESENTATION OR WARRANTY, WHETHER IT IS EXPRESS, IMPLIED, OR STATUTORY. WITHOUT LIMITING THE FOREGOING, VIRUSTOTAL SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT.

WE DO NOT WARRANT OR GUARANTEE THAT THE SERVICES ARE ACCURATE, RELIABLE OR CORRECT; THAT THE SERVICES WILL MEET YOUR REQUIREMENTS; THAT THE SERVICES WILL BE AVAILABLE AT ANY PARTICULAR TIME OR LOCATION, UNINTERRUPTED, ERROR-FREE, WITHOUT DEFECT OR SECURE; THAT ANY DEFECTS OR ERRORS WILL BE CORRECTED; OR THAT THE SERVICES ARE FREE OF VIRUSES OR OTHER HARMFUL COMPONENTS. 

We will not be liable for any loss or damage caused by a distributed denial-of-service attack, viruses or other technologically harmful material that may infect your computer equipment, computer programs, data or other proprietary material due to your access to or use of the Service or any third-party content or websites accessed through, or in any way in conjunction with, the Service.

Our Service may contain links to third-party websites or resources, which in turn may contain comments and/or posts with non-anchored linked URLs. You acknowledge and agree that we are not responsible or liable for: (i) the availability or accuracy of such websites or resources; or (ii) the content, products, or services on or available from such websites or resources. Links to such websites or resources do not imply any endorsement by VirusTotal of such websites or resources or the content, products, or services available from such websites or resources. You acknowledge sole responsibility for and assume all risk arising from your use of any such websites or resources and acknowledge that user comments on URLs and Samples in the Service, on the Site, and through connected third-party resources, may contain URLs/links leading to malware. VIRUSTOTAL MAKES NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED, WITH RESPECT TO SUCH THIRD-PARTY WEBSITES, PRODUCTS OR CONTENT AND EXPRESSLY DISCLAIMS ANY WARRANTY OR CONDITION OF MERCHANTABILITY, NON-INFRINGEMENT, OR FITNESS FOR A PARTICULAR PURPOSE.

Except as may be required by law and as set forth in our [Privacy Policy](/docs/privacy-policy), you further understand and agree that VirusTotal has no responsibility or liability for the deletion of, or the failure to store or transmit, any Sample, Content, other materials or communications maintained by the Service.

**Limitation of Liability**

TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, VIRUSTOTAL AND ITS PARENT, SUBSIDIARIES, AFFILIATES, OFFICERS, EMPLOYEES, AGENTS, PARTNERS AND LICENSORS WILL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL , EXEMPLARY OR PUNITIVE DAMAGES, INCLUDING WITHOUT LIMITATION, LOSS OF PROFITS, DATA, USE, GOODWILL, OR OTHER LOSSES, RESULTING FROM (i) YOUR ACCESS TO OR USE OF OR INABILITY TO ACCESS OR USE THE SERVICES; (ii) ANY CONDUCT OR CONTENT OF ANY THIRD PARTY, INCLUDING WITHOUT LIMITATION, ANY DEFAMATORY, OFFENSIVE OR ILLEGAL CONDUCT OF OTHER USERS OR THIRD PARTIES; (iii) ANY CONTENT OBTAINED FROM THE SERVICES; AND (iv) UNAUTHORISED ACCESS, USE OR ALTERATION OF YOUR TRANSMISSIONS, SAMPLES OR CONTENT, WHETHER BASED ON WARRANTY, CONTRACT, TORT (INCLUDING NEGLIGENCE) OR ANY OTHER LEGAL THEORY, WHETHER OR NOT WE HAVE BEEN INFORMED OF THE POSSIBILITY OF SUCH DAMAGE.

THIS LIMITATION OF LIABILITY SECTION APPLIES WHETHER THE ALLEGED LIABILITY IS BASED ON CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY, OR ANY OTHER BASIS, EVEN IF VIRUSTOTAL HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. THE FOREGOING LIMITATION OF LIABILITY WILL APPLY TO THE FULLEST EXTENT PERMITTED BY LAW IN THE APPLICABLE JURISDICTION.

**About These Terms**

Please note that we may update and amend these Terms from time to time and any changes will be posted on the Site. By continuing to access the Service after any changes become effective, you agree to be bound by the revised Terms.

The failure of VirusTotal to enforce any right or provision of these Terms will not be deemed a waiver of such right or provision. In the event that any provision of these Terms is held to be invalid or unenforceable, the remaining provisions of these Terms will remain in full force and effect.

These Terms and any dispute or claim arising out of or in connection with them or their subject matter or formation (including non-contractual disputes or claims) shall be governed by and construed in accordance with the laws of Ireland. The Irish courts will have exclusive jurisdiction over any claim arising from, or related to, the Service although we retain the right to bring proceedings against you for breach of the Terms in your country of residence or any other relevant country.

If you have any doubts as to whether your use of the Service complies with these Terms or have a concern with any aspect of the Site or the Service, please [Contact Us](https://www.virustotal.com/gui/contact-us/other).

**Last Updated Dec 11, 2018**

**Welcome**

These Terms of Service govern your access to and use of [www.virustotal.com](http://www.virustotal.com) (our “**Site**”) and our products and services (collectively, the "**Service**"), and any information, text, graphics, URLs, files, audio, video, photos or other materials uploaded, downloaded or appearing on the Service ("**Samples**"). Any reference to “you” or “your” means you as a user of the Service, any reference to “we”, “us”, “our” or “VirusTotal” is to Chronicle Security Ireland Limited (“**CSIL**”), an Irish Limited Company with registered number 507502, the company that owns VirusTotal. Both VirusTotal and CSIL are owned by Chronicle LLC.

Whether you are a member of the public, an antivirus, scanning, sandbox or other security partner (“**Partner**”), or a security-minded organization (collectively, the “**Community**”) using and contributing Samples to the Service, by using any part of the Service, you agree and consent to these Terms of Service including terms that limit our liability or affect your legal rights, any referenced and incorporated guidelines and policies, including our [**Sample & Community Content Guidelines**](#sample-community-content-guidelines) (which explain how to safely share Samples through the Service), the terms of our [**Privacy Policy**](/docs/privacy-policy) (which explains how we may collect, use and share personal information you provide to us), and any additional terms specific to your particular use of the Service which become part of your agreement with us (collectively, the “**Terms**”). If you are using the Service on behalf of a business, you represent to us that you have authority to bind that business or entity to these Terms, and that business accepts these Terms.  

**Restrictions on Your Use of the Service**

You agree that you may not use or attempt to:

- Use the Service in any way that breaches any applicable local, national, or international law or regulation.

- Use the Service in any way which could infringe the rights or interests of VirusTotal, the Community or any third party, including for example, to prove or disprove a concept or discredit, or bait any actor in the anti-malware space.

- Copy, reproduce, alter, modify, create derivative works, publicly display, republish, upload, post, transmit, resell or distribute in any way material, information or functionalities from the Service – including, without limitation, using the Service in any way for antivirus/URL scanner testing or that could directly or indirectly harm, compete with, or otherwise hinder the antivirus industry/URL scanner industry.

- Transfer any rights granted to you under the Terms.

- Use the Service for any illegal activity or output, or in any way that exposes VirusTotal, you, members of the Community or our Partners to harm.

- Engage in any activity that could damage, overload, harm or impede the normal functioning of the Service.

- Obtain or use any Samples except as specifically permitted by the Service or use or attempt to use the Service to mine information in any way that could identify individual persons in their private capacity, attempt to access or misappropriate content contained in any Sample, or otherwise use the Service or Samples for any purpose other than to detect and prevent malware in a non-commercial personal or organizational capacity.

- Publicly attribute the intelligence you receive through the Service to any VirusTotal Partner (antivirus vendors, URL scanning engines, file characterization tools, etc.) without the individual Partner’s express permission.

- Attempt to gain unauthorized access to our Site, the server on which our Site is stored or any server, computer or database connected to our Site.

- Attack, or attempt to attack our Site via a denial-of-service attack or a distributed denial-of service attack.

- Use or allow any third party under your control to submit Samples that are subject to the International Traffic in Arms Regulations (“**ITAR**”) maintained by the U.S. Department of State or do any other thing to cause CSIL to provide a defense service as defined by the ITAR, or otherwise use the Service except as expressly allowed under these Terms.

**Safe Participation in the Community**

While VirusTotal has commercial relationships with select members of the Community (organizations, institutions and Partners) public access to the VirusTotal Site is only available free of charge.

VirusTotal offers certain functionality that may require the creation of a personal account (e.g. to participate in the VirusTotal Community). Depending on the information provided in the registration and profile building process, your account may uniquely identify you. Any comment, post or other activity you engage in with the Community when using your account will generate content attributed to you (“**Content**”).

To the extent you use any password/keys/credentials to access the Service, you are exclusively responsible for generating unique and complex credentials, safeguarding them, and for any activities or actions taken on the Service using such credentials.

**Sample & Community Content Guidelines**

To the extent you elect to contribute any Sample to the Community, you confirm that all content contained in the Sample complies with these Terms and our [Privacy Policy](/docs/privacy-policy), that you are either the original owner of the Sample you submit or that you have the necessary rights and permissions to irrevocably contribute the Sample and share it, and information about it, with the Community.

You understand that if you submitting any Sample, the Sample is immediately shared for review by the Service’s Partners, and the resulting intelligence report is shared with you and, and with the Partners, which use the results to improve their own systems. As such, by contributing a Sample, you are contributing to the effort to raise global IT security levels.

While you retain any ownership rights in the original material contained in the Sample, when you upload or otherwise submit a copy of the Sample, you give VirusTotal (and those we work with) a worldwide, royalty free, irrevocable and transferable licence to use, edit, host, store, reproduce, modify, create derivative works, communicate, publish, publicly perform, publicly display and distribute all content contained in the Sample.

YOU FURTHER AGREE THAT YOU WILL ONLY UPLOAD SAMPLES THAT YOU WISH TO PUBLICLY SHARE AND THAT IN ANY CASE, YOU WILL NOT KNOWINGLY SUBMIT ANY SAMPLE TO THE SERVICE THAT CONTAINS CONFIDENTIAL OR COMMERCIALLY SENSITIVE DATA OR PERSONAL DATA OF ANY INDIVIDUAL WITHOUT LAWFUL PERMISSION.

Although we have no obligation to monitor use of the Service, user Content or any Samples, we may monitor the Service to detect and prevent fraudulent activity or violations of these Terms and retain absolute discretion to remove Samples, Content or users from the Service at any time and for any reason without notice. At the same time, to promote the security of the Community and information sharing accountability, accounts and Samples contributed by the Community (for example, comments, posts, etc.) generally will not be removed from the Service, unless they are illegal, violate the lawful rights of an individual, serve any other unethical/malicious purpose, or otherwise violate these Terms.

IF YOU DO NOT WANT TO PUBLICLY SHARE A SAMPLE IN THE MANNER SET OUT IN THESE TERMS OR IN THE [PRIVACY POLICY](/docs/privacy-policy), DO NOT SEND IT/CONTRIBUTE IT TO THE SERVICE AS THE SERVICE IS DESIGNED TO WORK THROUGH THE COLLECTIVE AGGREGATION AND SHARING OF THREAT-INTELLIGENCE WITH AND THROUGH THE COMMUNITY.

**VirusTotal Rights**

All rights, title, and interest in and to the Service (excluding third party brand names) are and will remain the exclusive property of VirusTotal and its licensors. Nothing in these Terms should be construed as conferring by implication or otherwise any license or right under any copyright, patent, trademark, database right, sui generis right or other intellectual property or proprietary interest of VirusTotal, its licensors or any third party. We reserve the right to remove any Samples without prior notice and at our sole discretion. Nothing in our Terms gives you a right to use the VirusTotal trademarks, logos, domain names, and other distinctive brand features.

Any Samples, feedback, comments, or suggestions you may provide to, or regarding VirusTotal or the Service is entirely voluntary. We are free to use any feedback, comments or suggestions as we see fit and without obligation to you and reserve the right to remove any Sample without prior notice and at our sole discretion.

**Changes in Service**

The Service provided by VirusTotal is constantly evolving, and the form and nature of the Service that VirusTotal provides may change from time to time without prior notice to you. Any changes to the Service, including the release of new VirusTotal features, are subject to the Terms then in effect. In addition, VirusTotal may stop (permanently or temporarily) providing the Service (or any features within the Service) without providing prior notice. We also retain the right to create limits on your use of the Service including storage, at our sole discretion, at any time without prior notice to you.

**Disclaimers**

Your access to and use of the Service is at your own risk. You understand and agree that the Service is provided to you on an "AS IS" WITHOUT REPRESENTATION OR WARRANTY, WHETHER IT IS EXPRESS, IMPLIED, OR STATUTORY. WITHOUT LIMITING THE FOREGOING, VIRUSTOTAL SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT.

WE DO NOT WARRANT OR GUARANTEE THAT THE SERVICES ARE ACCURATE, RELIABLE OR CORRECT; THAT THE SERVICES WILL MEET YOUR REQUIREMENTS; THAT THE SERVICES WILL BE AVAILABLE AT ANY PARTICULAR TIME OR LOCATION, UNINTERRUPTED, ERROR-FREE, WITHOUT DEFECT OR SECURE; THAT ANY DEFECTS OR ERRORS WILL BE CORRECTED; OR THAT THE SERVICES ARE FREE OF VIRUSES OR OTHER HARMFUL COMPONENTS. 

We will not be liable for any loss or damage caused by a distributed denial-of-service attack, viruses or other technologically harmful material that may infect your computer equipment, computer programs, data or other proprietary material due to your access to or use of the Service or any third-party content or websites accessed through, or in any way in conjunction with, the Service.

Our Service may contain links to third-party websites or resources, which in turn may contain comments and/or posts with non-anchored linked URLs. You acknowledge and agree that we are not responsible or liable for: (i) the availability or accuracy of such websites or resources; or (ii) the content, products, or services on or available from such websites or resources. Links to such websites or resources do not imply any endorsement by VirusTotal of such websites or resources or the content, products, or services available from such websites or resources. You acknowledge sole responsibility for and assume all risk arising from your use of any such websites or resources and acknowledge that user comments on URLs and Samples in the Service, on the Site, and through connected third-party resources, may contain URLs/links leading to malware. VIRUSTOTAL MAKES NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED, WITH RESPECT TO SUCH THIRD-PARTY WEBSITES, PRODUCTS OR CONTENT AND EXPRESSLY DISCLAIMS ANY WARRANTY OR CONDITION OF MERCHANTABILITY, NON-INFRINGEMENT, OR FITNESS FOR A PARTICULAR PURPOSE.

Except as may be required by law and as set forth in our [Privacy Policy](/docs/privacy-policy), you further understand and agree that VirusTotal has no responsibility or liability for the deletion of, or the failure to store or transmit, any Sample, Content, other materials or communications maintained by the Service.

**Limitation of Liability**

TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, VIRUSTOTAL AND ITS PARENT, SUBSIDIARIES, AFFILIATES, OFFICERS, EMPLOYEES, AGENTS, PARTNERS AND LICENSORS WILL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL , EXEMPLARY OR PUNITIVE DAMAGES, INCLUDING WITHOUT LIMITATION, LOSS OF PROFITS, DATA, USE, GOODWILL, OR OTHER LOSSES, RESULTING FROM (i) YOUR ACCESS TO OR USE OF OR INABILITY TO ACCESS OR USE THE SERVICES; (ii) ANY CONDUCT OR CONTENT OF ANY THIRD PARTY, INCLUDING WITHOUT LIMITATION, ANY DEFAMATORY, OFFENSIVE OR ILLEGAL CONDUCT OF OTHER USERS OR THIRD PARTIES; (iii) ANY CONTENT OBTAINED FROM THE SERVICES; AND (iv) UNAUTHORISED ACCESS, USE OR ALTERATION OF YOUR TRANSMISSIONS, SAMPLES OR CONTENT, WHETHER BASED ON WARRANTY, CONTRACT, TORT (INCLUDING NEGLIGENCE) OR ANY OTHER LEGAL THEORY, WHETHER OR NOT WE HAVE BEEN INFORMED OF THE POSSIBILITY OF SUCH DAMAGE.

THIS LIMITATION OF LIABILITY SECTION APPLIES WHETHER THE ALLEGED LIABILITY IS BASED ON CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY, OR ANY OTHER BASIS, EVEN IF VIRUSTOTAL HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. THE FOREGOING LIMITATION OF LIABILITY WILL APPLY TO THE FULLEST EXTENT PERMITTED BY LAW IN THE APPLICABLE JURISDICTION.

**About These Terms**

Please note that we may update and amend these Terms from time to time and any changes will be posted on the Site. By continuing to access the Service after any changes become effective, you agree to be bound by the revised Terms.

The failure of VirusTotal to enforce any right or provision of these Terms will not be deemed a waiver of such right or provision. In the event that any provision of these Terms is held to be invalid or unenforceable, the remaining provisions of these Terms will remain in full force and effect.

These Terms and any dispute or claim arising out of or in connection with them or their subject matter or formation (including non-contractual disputes or claims) shall be governed by and construed in accordance with the laws of Ireland. The Irish courts will have exclusive jurisdiction over any claim arising from, or related to, the Service although we retain the right to bring proceedings against you for breach of the Terms in your country of residence or any other relevant country.

If you have any doubts as to whether your use of the Service complies with these Terms or have a concern with any aspect of the Site or the Service, please [Contact Us](https://www.virustotal.com/gui/contact-us/other).

**Updated about 2 months ago