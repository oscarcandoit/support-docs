---
title: "External behavioural engines sandboxes"
source: "https://docs.virustotal.com/docs/external-sandboxes"
scraped_at: "2026-02-08T06:19:20.685Z"
---

VirusTotal incorporates various third party behavioural engines sandboxes to give a broad vision of indicators that can come from the different sandboxes in the market. Find below a summary of different capabilities from our current external behavioural engines sandboxes:

| Commercial Name | Type of Files | PCAP | Low Level Report | MITRE Signatures |
| --- | --- | --- | --- | --- |
| [Bitdam ATP (Bitdam)](https://bitdam.com/) | MS Office Documents, RTF, PDF | No | No | No |
| C2AE | MSI, EXE, DLL, JAR, ZIP, RAR, PDF, MSI, Office Documents, Scripts, PHP | No | No | No |
| [DAS-Security Orcas](https://www.dbappsecurity.com.cn/) | EXE, DLL, ZIP, RAR, Powershell, Scripts, MSI, JAR, PDF | Yes | No | Yes |
| [Dr. Web VxCube (Dr Web)](https://www.drweb.com/vxcube/) | DLL, EXE, Android application (APK), scripts, powershell, MS Office Documents, PDF | Yes | Yes | No |
| [ELF DIGEST](https://elfdigest.com/) | ELF | Yes | No | No |
| [LastLine](https://www.lastline.com) | DLL, EXE, MS Office Documents, JAR, scripts, BAT, PDF | No | No | No |
| [Microsoft SysInternals](https://learn.microsoft.com/en-us/sysinternals/) | EXE, MZ | No | No | No |
| [NSFOCUS POMA (NSFOCUS)](https://poma.nsfocus.com/) | EXE, DLL, PDF, Scripts, MSI, MZ, Powershell, MS Office Documents | No | Yes | No |
| [QiAnXin RedDrip (QiAnXin)](https://sandbox.ti.qianxin.com/sandbox/page) | EXE, DLL, ZIP, RAR, PDF, MS Office Documents, Scripts, CHM | No | No | No |
| [ReaQta-Hive (ReaQta)](https://reaqta.com/hive/) | EXE, DLL, MS Office Documents, Scripts | No | Yes | No |
| [Rising MOVES](http://ep.rising.com.cn/wangguan/19584.html) | EXE, DLL, ZIP, MSI, MS Office Documents, Scripts | No | Yes | No |
| [Sangfor ZSand (ZSand)](https://www.sangfor.com/innovations/zsand.html) | EXE | Yes | No | No |
| [SecneurX](https://www.secneurx.com/) | Android application (APK), EXE, PDF, ZIP, MS Office Documents, Scripts, DLL, MSI, Powershell, ELF | No | Yes | No |
| [SecondWrite Deep View (SecondWrite)](https://www.secondwrite.com/?utm_source=virus_total) | EXE, DLL, PDF, MS Office Document, Scripts | Yes | Yes | Yes |
| [Tencent (HABO)](https://habo.qq.com/) | EXE, Android applications (APK), MS Office Documents, ELF, MSI | No | Yes | No |
| [Venuseye (venuseye)](https://www.venuseye.com.cn/) | EXE, MS Office Document, ZIP, MSI, Android application (APK), DLL | No | Yes | No |
| [VMRay](https://www.vmray.com/) | EXE, DLL, MS Office Documents, Scripts, PDF, MSI | No | No | No |
| [Yomi Hunter (Yoroi)](https://blog.yoroi.company/announcement/yoroi-welcomes-yomi-the-malware-hunter/) | EXE, Android application (APK), MS Office Docs | Yes | Yes | Yes |

In addition to the products mentioned above, VirusTotal also includes its own in-house sandboxes and behavioural analysis products, the list can be found [here](/docs/in-house-sandboxes).

**Updated about 2 months ago